from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "reproduce_relaxed.py"


def load_script_module():
    specification = importlib.util.spec_from_file_location("cadprocal_relaxed_reproduction", SCRIPT)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def test_all_reference_tables_are_present():
    expected = {
        "ablation.csv",
        "baseline_cv.csv",
        "calibration.csv",
        "efficiency.csv",
        "external_validation.csv",
        "internal_cv.csv",
        "interpretability.csv",
        "robustness.csv",
        "statistics.csv",
    }
    assert {path.name for path in (ROOT / "reference_targets").glob("*.csv")} == expected


def test_relaxed_numerical_targets_pass():
    module = load_script_module()
    tables = module.load_tables(ROOT / "reference_targets")
    checks = module.build_checks(tables)
    assert len(checks) >= 25
    assert all(check.status == "PASS" for check in checks)


def test_all_six_figures_build(tmp_path):
    module = load_script_module()
    tables = module.load_tables(ROOT / "reference_targets")
    figures = module.build_figures(tables, tmp_path)
    assert len(figures) == 6
    assert all((tmp_path / name).stat().st_size > 10_000 for name in figures)

