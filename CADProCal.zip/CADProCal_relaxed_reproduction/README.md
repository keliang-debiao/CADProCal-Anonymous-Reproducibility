# CADProCal 最宽松协议复现

本工程以“结果对齐”为验收标准，从所附论文的 Tables 6–16 固化机器可读参考目标，重新计算五折汇总，并重建 Figures 3–8。

## 一键运行

在 PowerShell 中执行：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run_relaxed.ps1
```

脚本使用 `uv` 创建隔离的 Python 3.11 执行环境，完成：

1. 五折均值和样本标准差重算；
2. 内部、外部、消融、校准、鲁棒性、统计、效率和可解释性目标核验；
3. Figures 3–8 重建；
4. 参考表 SHA-256 固化；
5. 自动化测试。

结果写入 `outputs/relaxed_reproduction/`。

## 证据等级

这是论文结果目标重构，不是 Eedi 与 MAP 原始数据上的独立模型重训。论文声明代码需向作者索取，且完整重训还需要 Kaggle 数据、精确数据处理代码、逐折模型权重、逐样本预测与硬件环境。为避免夸大，报告和 JSON 摘要都明确记录这一证据边界。

Figure 7 的逐置信度箱数据未在论文表格中给出，因此本工程使用论文报告的 ECE 和扰动轨迹重建该图的数值结论，而不声称恢复了原始 reliability-bin 输出。

