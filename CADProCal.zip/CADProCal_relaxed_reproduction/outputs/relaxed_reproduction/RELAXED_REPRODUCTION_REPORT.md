# CADProCal 最宽松协议复现报告

- 协议：`relaxed_manuscript_target_reconstruction`
- 数值检查：36/36 通过
- 默认容差：0.0005
- 证据等级：论文表格目标重构，不是公开原始数据上的独立模型重训

本协议从论文表格固化参考目标，重新计算五折汇总，交叉核验内部、外部、消融、校准、鲁棒性、统计、效率和可解释性结果，并据此重建 Figures 3–8。

## 核心数值核验

| 结果 | 目标值 | 复现值 | 绝对误差 | 状态 |
|---|---:|---:|---:|:---:|
| Internal MAP@25 mean | 0.562 | 0.562 | 0 | PASS |
| Internal MAP@25 SD | 0.008 | 0.00796869 | 3.13e-05 | PASS |
| Internal Recall@25 mean | 0.817 | 0.817 | 0 | PASS |
| Internal Recall@25 SD | 0.01 | 0.00966954 | 0.00033 | PASS |
| Internal Top-1 accuracy mean | 0.367 | 0.3666 | 0.0004 | PASS |
| Internal Top-1 accuracy SD | 0.009 | 0.00896103 | 3.9e-05 | PASS |
| Internal Macro-F1 mean | 0.22 | 0.2204 | 0.0004 | PASS |
| Internal Macro-F1 SD | 0.008 | 0.00841427 | 0.000414 | PASS |
| Internal ECE mean | 0.044 | 0.0438 | 0.0002 | PASS |
| Internal ECE SD | 0.004 | 0.00396232 | 3.77e-05 | PASS |
| Internal Top-label Brier mean | 0.211 | 0.2106 | 0.0004 | PASS |
| Internal Top-label Brier SD | 0.006 | 0.0061887 | 0.000189 | PASS |
| ModernBERT-base bi-encoder MAP@25 mean | 0.523 | 0.5228 | 0.0002 | PASS |
| Qwen3-Reranker-0.6B MAP@25 mean | 0.556 | 0.5558 | 0.0002 | PASS |
| CADProCal MAP@25 mean | 0.562 | 0.562 | 0 | PASS |
| External CADProCal map_at_3 | 0.748 | 0.748 | 0 | PASS |
| External CADProCal ece | 0.061 | 0.061 | 0 | PASS |
| External CADProCal coverage_90 | 0.872 | 0.872 | 0 | PASS |
| External CADProCal mean_set_size_90 | 3.8 | 3.8 | 0 | PASS |
| External Qwen3-Reranker-0.6B map_at_3 | 0.756 | 0.756 | 0 | PASS |
| External Qwen3-Reranker-0.6B ece | 0.083 | 0.083 | 0 | PASS |
| Full-model MAP@25 | 0.562 | 0.562 | 0 | PASS |
| Response-residual ablation delta | -0.018 | -0.018 | 1.73e-17 | PASS |
| Uncalibrated internal ECE | 0.091 | 0.091 | 0 | PASS |
| Temperature-scaled internal ECE | 0.044 | 0.044 | 0 | PASS |
| Frozen external 90% coverage | 0.872 | 0.872 | 0 | PASS |
| External exact-deduplicated MAP@3 | 0.745 | 0.745 | 0 | PASS |
| External fuzzy-overlap-removed MAP@3 | 0.741 | 0.741 | 0 | PASS |
| Internal reranker paired difference | 0.006 | 0.006 | 0 | PASS |
| Internal reranker Holm p | 0.281 | 0.281 | 0 | PASS |
| External ECE paired difference | -0.022 | -0.022 | 0 | PASS |
| External ECE Holm p | 0.036 | 0.036 | 0 | PASS |
| CADProCal inference parameters | 157 | 157 | 0 | PASS |
| CADProCal FLOPs/query | 36.9 | 36.9 | 0 | PASS |
| CADProCal batch-1 latency | 10.9 | 10.9 | 0 | PASS |
| Response/explanation attribution mass | 0.624 | 0.624 | 0 | PASS |

## 重建图表

- `figure3_five_fold_performance.png`
- `figure4_map_vs_parameters.png`
- `figure5_external_validation.png`
- `figure6_ablation.png`
- `figure7_calibration_robustness.png`
- `figure8_statistical_comparisons.png`

## 证据边界

Figure 7 的论文没有提供逐置信度箱原始数据，因此复现图用表 12 的 ECE 与表 13 的扰动轨迹进行确定性重建；其数值结论与论文一致，但不冒充原始 reliability-bin 输出。正式重训仍需要 Kaggle 数据、精确预处理、模型权重、逐折预测和硬件记录。
