$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$OutputDirectory = Join-Path $ProjectRoot "outputs\relaxed_reproduction"

Push-Location $ProjectRoot
try {
    uv run --no-project --python 3.11 --with-requirements requirements-relaxed.txt `
        python scripts/reproduce_relaxed.py --output-dir $OutputDirectory
    if ($LASTEXITCODE -ne 0) {
        throw "Relaxed reproduction failed with exit code $LASTEXITCODE."
    }

    uv run --no-project --python 3.11 --with-requirements requirements-relaxed.txt `
        python -m pytest -q
    if ($LASTEXITCODE -ne 0) {
        throw "Test suite failed with exit code $LASTEXITCODE."
    }
}
finally {
    Pop-Location
}

