from __future__ import annotations

import argparse
import sys
from pathlib import Path

from docx import Document


def main() -> None:
    parser = argparse.ArgumentParser(description="Print paragraph and table text from a DOCX file.")
    parser.add_argument("document", type=Path)
    parser.add_argument("--tables-only", action="store_true")
    args = parser.parse_args()
    sys.stdout.reconfigure(encoding="utf-8")

    document = Document(args.document)
    if not args.tables_only:
        print("=== PARAGRAPHS ===")
        for index, paragraph in enumerate(document.paragraphs, start=1):
            text = " ".join(paragraph.text.split())
            if text:
                print(f"P{index:04d}\t{paragraph.style.name}\t{text}")

    print("=== TABLES ===")
    for table_index, table in enumerate(document.tables, start=1):
        print(f"--- TABLE {table_index} ({len(table.rows)}x{len(table.columns)}) ---")
        for row_index, row in enumerate(table.rows, start=1):
            cells = [" ".join(cell.text.split()) for cell in row.cells]
            print(f"T{table_index:02d}R{row_index:03d}\t" + "\t".join(cells))


if __name__ == "__main__":
    main()
