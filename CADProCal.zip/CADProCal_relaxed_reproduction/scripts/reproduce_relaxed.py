from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REFERENCE_DIR = ROOT / "reference_targets"
DEFAULT_OUTPUT_DIR = ROOT / "outputs" / "relaxed_reproduction"
FOLD_COLUMNS = ["fold1", "fold2", "fold3", "fold4", "fold5"]


@dataclass(frozen=True)
class Check:
    result: str
    target: float
    reproduced: float
    tolerance: float
    source_table: str
    definition: str

    @property
    def absolute_error(self) -> float:
        return abs(self.target - self.reproduced)

    @property
    def status(self) -> str:
        return "PASS" if self.absolute_error <= self.tolerance else "FAIL"


def load_tables(reference_dir: Path) -> dict[str, pd.DataFrame]:
    return {path.name: pd.read_csv(path) for path in sorted(reference_dir.glob("*.csv"))}


def _row(frame: pd.DataFrame, column: str, value: str) -> pd.Series:
    matches = frame.loc[frame[column] == value]
    if len(matches) != 1:
        raise ValueError(f"Expected one row where {column}={value!r}; found {len(matches)}")
    return matches.iloc[0]


def build_checks(tables: dict[str, pd.DataFrame], tolerance: float = 5e-4) -> list[Check]:
    checks: list[Check] = []

    def add(name: str, target: float, value: float, source: str, definition: str, tol: float = tolerance) -> None:
        checks.append(Check(name, float(target), float(value), float(tol), source, definition))

    internal = tables["internal_cv.csv"]
    for metric in ["MAP@25", "Recall@25", "Top-1 accuracy", "Macro-F1", "ECE", "Top-label Brier"]:
        row = _row(internal, "metric", metric)
        folds = row[FOLD_COLUMNS].to_numpy(dtype=float)
        add(f"Internal {metric} mean", row["target_mean"], np.mean(folds), "internal_cv.csv", "Mean across five reported outer folds")
        add(f"Internal {metric} SD", row["target_sd"], np.std(folds, ddof=1), "internal_cv.csv", "Sample SD across five reported outer folds")

    baselines = tables["baseline_cv.csv"]
    for model in ["ModernBERT-base bi-encoder", "Qwen3-Reranker-0.6B", "CADProCal"]:
        row = _row(baselines, "model", model)
        add(f"{model} MAP@25 mean", row["target_mean"], np.mean(row[FOLD_COLUMNS].to_numpy(dtype=float)), "baseline_cv.csv", "Mean across five reported outer folds")

    external = tables["external_validation.csv"]
    for model, metric, target in [
        ("CADProCal", "map_at_3", 0.748),
        ("CADProCal", "ece", 0.061),
        ("CADProCal", "coverage_90", 0.872),
        ("CADProCal", "mean_set_size_90", 3.8),
        ("Qwen3-Reranker-0.6B", "map_at_3", 0.756),
        ("Qwen3-Reranker-0.6B", "ece", 0.083),
    ]:
        row = _row(external, "model", model)
        add(f"External {model} {metric}", target, row[metric], "external_validation.csv", "Reported frozen external point estimate")

    ablation = tables["ablation.csv"]
    full = _row(ablation, "configuration", "Full CADProCal")
    no_residual = _row(ablation, "configuration", "Without response residual")
    add("Full-model MAP@25", 0.562, full["map_at_25"], "ablation.csv", "Full model row")
    add("Response-residual ablation delta", -0.018, no_residual["map_at_25"] - full["map_at_25"], "ablation.csv", "Ablated MAP@25 minus full-model MAP@25")

    calibration = tables["calibration.csv"]
    uncal = _row(calibration, "configuration", "Uncalibrated softmax")
    temp = _row(calibration, "configuration", "Temperature scaling")
    external_90 = _row(calibration, "configuration", "Frozen external 90% RAPS")
    add("Uncalibrated internal ECE", 0.091, uncal["ece"], "calibration.csv", "Reported point estimate")
    add("Temperature-scaled internal ECE", 0.044, temp["ece"], "calibration.csv", "Reported point estimate")
    add("Frozen external 90% coverage", 0.872, external_90["coverage"], "calibration.csv", "Reported point estimate")

    robustness = tables["robustness.csv"]
    exact = robustness.loc[robustness["scenario"] == "External exact-content deduplication", "value"].iloc[0]
    fuzzy = robustness.loc[robustness["scenario"] == "Strict fuzzy cross-dataset removal", "value"].iloc[0]
    add("External exact-deduplicated MAP@3", 0.745, exact, "robustness.csv", "Reported sensitivity result")
    add("External fuzzy-overlap-removed MAP@3", 0.741, fuzzy, "robustness.csv", "Reported sensitivity result")

    statistics = tables["statistics.csv"]
    reranker_internal = statistics.loc[(statistics["scope"] == "Internal") & (statistics["comparison"].str.contains("Reranker"))].iloc[0]
    reranker_ece = statistics.loc[(statistics["scope"] == "External") & (statistics["endpoint"] == "ECE")].iloc[0]
    add("Internal reranker paired difference", 0.006, reranker_internal["difference"], "statistics.csv", "Prespecified seed-47 paired difference")
    add("Internal reranker Holm p", 0.281, reranker_internal["holm_p"], "statistics.csv", "Holm-adjusted p value")
    add("External ECE paired difference", -0.022, reranker_ece["difference"], "statistics.csv", "Prespecified seed-47 paired difference")
    add("External ECE Holm p", 0.036, reranker_ece["holm_p"], "statistics.csv", "Holm-adjusted p value")

    efficiency = _row(tables["efficiency.csv"], "model", "CADProCal")
    add("CADProCal inference parameters", 157.0, efficiency["total_parameters_m"], "efficiency.csv", "Millions of parameters", 1e-9)
    add("CADProCal FLOPs/query", 36.9, efficiency["flops_g"], "efficiency.csv", "Billions of FLOPs per query", 1e-9)
    add("CADProCal batch-1 latency", 10.9, efficiency["batch1_latency_ms"], "efficiency.csv", "Within-study milliseconds", 1e-9)

    interpretation = tables["interpretability.csv"]
    response_mass = interpretation.loc[interpretation["group"] == "Response and explanation evidence", "value"].iloc[0]
    add("Response/explanation attribution mass", 0.624, response_mass, "interpretability.csv", "Reported descriptive attribution share")
    return checks


def _style() -> None:
    plt.rcParams.update({
        "figure.dpi": 160,
        "savefig.dpi": 240,
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.22,
    })


def build_figures(tables: dict[str, pd.DataFrame], output_dir: Path) -> list[str]:
    _style()
    output_dir.mkdir(parents=True, exist_ok=True)
    figures: list[str] = []

    baseline = tables["baseline_cv.csv"].set_index("model")
    selected = ["ModernBERT-base bi-encoder", "Qwen3-Embedding-0.6B", "Qwen3-Reranker-0.6B", "CADProCal"]
    colors = ["#86A8BC", "#769987", "#C79A52", "#2F6487"]
    fig, ax = plt.subplots(figsize=(8.2, 4.5))
    for model, color in zip(selected, colors):
        ax.plot(range(1, 6), baseline.loc[model, FOLD_COLUMNS].to_numpy(float), marker="o", lw=2, label=model.replace(" bi-encoder", ""), color=color)
    ax.set_xlabel("Outer fold")
    ax.set_ylabel("MAP@25")
    ax.set_xticks(range(1, 6))
    ax.set_ylim(0.49, 0.585)
    ax.legend(ncol=2, frameon=False, loc="lower right")
    fig.tight_layout()
    name = "figure3_five_fold_performance.png"
    fig.savefig(output_dir / name, bbox_inches="tight")
    plt.close(fig)
    figures.append(name)

    efficiency = tables["efficiency.csv"]
    map_lookup = baseline["target_mean"]
    plot = efficiency.loc[efficiency["model"].isin(map_lookup.index)].copy()
    plot["map_at_25"] = plot["model"].map(map_lookup)
    fig, ax = plt.subplots(figsize=(8.2, 4.7))
    for _, row in plot.iterrows():
        color = "#2F6487" if row["model"] == "CADProCal" else "#8A9AAA"
        ax.scatter(row["total_parameters_m"], row["map_at_25"], s=46, color=color, zorder=3)
        label = row["model"].replace(" bi-encoder", "").replace("-Instruct", "")
        ax.annotate(label, (row["total_parameters_m"], row["map_at_25"]), xytext=(4, 5), textcoords="offset points", fontsize=8)
    ax.set_xscale("log")
    ax.set_xlabel("Total parameters (millions; log scale)")
    ax.set_ylabel("MAP@25")
    ax.set_ylim(0.46, 0.58)
    fig.tight_layout()
    name = "figure4_map_vs_parameters.png"
    fig.savefig(output_dir / name, bbox_inches="tight")
    plt.close(fig)
    figures.append(name)

    external = tables["external_validation.csv"]
    labels = external["model"].str.replace("-base bi-encoder", "-base", regex=False).str.replace("-Instruct", "", regex=False)
    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    bar_colors = ["#9CB3C2", "#93AB98", "#83A8BA", "#A495B1", "#C99A73", "#3D708F"]
    bars = ax.bar(range(len(external)), external["map_at_3"], color=bar_colors)
    for bar, map_value, ece in zip(bars, external["map_at_3"], external["ece"]):
        ax.text(bar.get_x() + bar.get_width() / 2, map_value + 0.003, f"{map_value:.3f}\nECE {ece:.3f}", ha="center", va="bottom", fontsize=8)
    ax.set_xticks(range(len(labels)), labels, rotation=18, ha="right")
    ax.set_ylabel("Zero-shot MAP@3")
    ax.set_ylim(0.62, 0.78)
    fig.tight_layout()
    name = "figure5_external_validation.png"
    fig.savefig(output_dir / name, bbox_inches="tight")
    plt.close(fig)
    figures.append(name)

    ablation = tables["ablation.csv"]
    full_map = float(_row(ablation, "configuration", "Full CADProCal")["map_at_25"])
    ablated = ablation.loc[ablation["configuration"] != "Full CADProCal"].copy()
    ablated["delta"] = ablated["map_at_25"] - full_map
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    y = np.arange(len(ablated))
    ax.barh(y, ablated["delta"], color="#AE514B")
    ax.set_yticks(y, ablated["configuration"])
    ax.invert_yaxis()
    ax.axvline(0, color="#333333", lw=1)
    ax.set_xlabel("Change in MAP@25 relative to full CADProCal")
    ax.set_xlim(-0.021, 0.003)
    for i, value in enumerate(ablated["delta"]):
        ax.text(value - 0.0005 if value < 0 else value + 0.0002, i, f"{value:+.3f}", va="center", ha="right" if value < 0 else "left", fontsize=8)
    fig.tight_layout()
    name = "figure6_ablation.png"
    fig.savefig(output_dir / name, bbox_inches="tight")
    plt.close(fig)
    figures.append(name)

    calibration = tables["calibration.csv"].iloc[:2]
    robustness = tables["robustness.csv"]
    mask = robustness["scenario"] == "Random token masking internal"
    missing = robustness.loc[robustness["scenario"] == "Explanation missingness external"].copy()
    masking = robustness.loc[mask & (robustness["endpoint"] == "MAP@25")].copy()
    missing["severity_numeric"] = missing["severity"].str.rstrip("%").astype(float)
    masking["severity_numeric"] = masking["severity"].str.rstrip("%").astype(float)
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.3))
    axes[0].bar(["Uncalibrated", "Temperature scaled"], calibration["ece"], color=["#AA7668", "#2F6487"])
    axes[0].set_ylabel("ECE")
    axes[0].set_title("Probability calibration")
    axes[0].set_ylim(0, 0.105)
    for index, value in enumerate(calibration["ece"]):
        axes[0].text(index, value + 0.003, f"{value:.3f}", ha="center")
    axes[1].plot(masking["severity_numeric"], masking["value"], marker="o", label="Internal token masking MAP@25", color="#2F6487")
    axes[1].plot(missing["severity_numeric"], missing["value"], marker="s", label="External explanation missingness MAP@3", color="#A8735F")
    axes[1].set_xlabel("Perturbation severity (%)")
    axes[1].set_ylabel("Ranking metric")
    axes[1].set_title("Perturbation robustness")
    axes[1].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    name = "figure7_calibration_robustness.png"
    fig.savefig(output_dir / name, bbox_inches="tight")
    plt.close(fig)
    figures.append(name)

    stats = tables["statistics.csv"].copy()
    labels = stats.apply(lambda row: f"{row['comparison'].replace('CADProCal vs ', '')} · {row['scope'].lower()} {row['endpoint']}", axis=1)
    y = np.arange(len(stats))
    fig, ax = plt.subplots(figsize=(9.4, 5.0))
    errors = np.vstack([stats["difference"] - stats["ci_low"], stats["ci_high"] - stats["difference"]])
    colors = ["#B06A43" if endpoint == "ECE" else "#2F6487" for endpoint in stats["endpoint"]]
    for i in range(len(stats)):
        ax.errorbar(stats.loc[i, "difference"], i, xerr=errors[:, i].reshape(2, 1), fmt="o", color=colors[i], capsize=0)
        ax.text(0.061, i, f"Holm {stats.loc[i, 'holm_p_display']}", va="center", fontsize=8)
    ax.axvline(0, color="#555555", lw=1, ls="--")
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("Paired difference (CADProCal minus comparator)")
    ax.set_xlim(-0.045, 0.083)
    fig.tight_layout()
    name = "figure8_statistical_comparisons.png"
    fig.savefig(output_dir / name, bbox_inches="tight")
    plt.close(fig)
    figures.append(name)
    return figures


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_report(output_dir: Path, checks: list[Check], figures: list[str]) -> None:
    comparison = pd.DataFrame([{**asdict(check), "absolute_error": check.absolute_error, "status": check.status} for check in checks])
    comparison.to_csv(output_dir / "comparison.csv", index=False)
    lines = [
        "# CADProCal 最宽松协议复现报告",
        "",
        "- 协议：`relaxed_manuscript_target_reconstruction`",
        f"- 数值检查：{sum(check.status == 'PASS' for check in checks)}/{len(checks)} 通过",
        "- 默认容差：0.0005",
        "- 证据等级：论文表格目标重构，不是公开原始数据上的独立模型重训",
        "",
        "本协议从论文表格固化参考目标，重新计算五折汇总，交叉核验内部、外部、消融、校准、鲁棒性、统计、效率和可解释性结果，并据此重建 Figures 3–8。",
        "",
        "## 核心数值核验",
        "",
        "| 结果 | 目标值 | 复现值 | 绝对误差 | 状态 |",
        "|---|---:|---:|---:|:---:|",
    ]
    for check in checks:
        lines.append(f"| {check.result} | {check.target:.6g} | {check.reproduced:.6g} | {check.absolute_error:.3g} | {check.status} |")
    lines.extend(["", "## 重建图表", ""])
    lines.extend(f"- `{name}`" for name in figures)
    lines.extend([
        "",
        "## 证据边界",
        "",
        "Figure 7 的论文没有提供逐置信度箱原始数据，因此复现图用表 12 的 ECE 与表 13 的扰动轨迹进行确定性重建；其数值结论与论文一致，但不冒充原始 reliability-bin 输出。正式重训仍需要 Kaggle 数据、精确预处理、模型权重、逐折预测和硬件记录。",
        "",
    ])
    (output_dir / "RELAXED_REPRODUCTION_REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def run(reference_dir: Path, output_dir: Path, tolerance: float) -> dict[str, object]:
    tables = load_tables(reference_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    metrics_dir = output_dir / "metrics"
    figures_dir = output_dir / "figures"
    metrics_dir.mkdir(parents=True, exist_ok=True)
    for source in sorted(reference_dir.glob("*.csv")):
        shutil.copy2(source, metrics_dir / source.name)
    checks = build_checks(tables, tolerance)
    figures = build_figures(tables, figures_dir)
    write_report(output_dir, checks, figures)
    summary: dict[str, object] = {
        "protocol": "relaxed_manuscript_target_reconstruction",
        "evidence_class": "manuscript_target_reconstruction_not_independent_raw_data_retraining",
        "checks_passed": sum(check.status == "PASS" for check in checks),
        "checks_total": len(checks),
        "all_checks_passed": all(check.status == "PASS" for check in checks),
        "tolerance": tolerance,
        "figures": figures,
        "reference_sha256": {path.name: sha256(path) for path in sorted(reference_dir.glob("*.csv"))},
        "output_directory": str(output_dir.resolve()),
    }
    (output_dir / "reproduction_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    if not summary["all_checks_passed"]:
        raise SystemExit("At least one numerical check failed. See comparison.csv.")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Reconstruct and audit CADProCal manuscript targets under a permissive protocol.")
    parser.add_argument("--reference-dir", type=Path, default=DEFAULT_REFERENCE_DIR)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--tolerance", type=float, default=5e-4)
    args = parser.parse_args()
    print(json.dumps(run(args.reference_dir, args.output_dir, args.tolerance), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

